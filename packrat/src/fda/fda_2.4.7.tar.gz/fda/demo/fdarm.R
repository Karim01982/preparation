# check all the script files for Functional Data Analysis with R and Matlab

source('scripts/fdarm-ch01.R')
source('scripts/fdarm-ch02.R')
source('scripts/fdarm-ch03.R')
source('scripts/fdarm-ch04.R')
source('scripts/fdarm-ch05.R')
source('scripts/fdarm-ch06.R')
source('scripts/fdarm-ch07.R')
source('scripts/fdarm-ch08.R')
source('scripts/fdarm-ch09.R')
source('scripts/fdarm-ch10.R')
source('scripts/fdarm-ch11.R')
